# OreUIForEveryone-1.21.1-Extend

此材质包是为OreUIForEveryone做的补充，适用于1.21.1版本

[OFE仓库](https://github.com/ReConstruction-127/OreUI-For-Everyone-1.20.1) [OFE1.21.1Patch仓库](https://github.com/LiPolymer/OreUI-For-Everyone-1.21.1) [OFE1.21.1Fork仓库](https://github.com/RyanLuoJiayuan1120/OreUI-For-Everyone-forked)

需要放在OFE之上，并且请使用1.21.1版OFE 或者使用fork版OFE，fork版会同步此仓库

可能在后续合并进主仓库

目前已完成

- Curios修正
- Just Dire Things
- JDTE
- Mek修正
- 莱特兰恶意
- 莱特兰标签页
- 莱特曼货币
- 神话系列（部分修改

正在制作

- 精致存储