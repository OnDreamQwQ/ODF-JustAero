#version 150

#moj_import <fog.glsl>

uniform sampler2D Sampler0;
uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;

in float vertexDistance;
in vec4 vertexColor;
in vec4 lightMapColor;
in vec2 texCoord0;
in vec4 normal;

out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    
    // ⭐ 关键：不乘以 lightMapColor，无视光照
    // color *= lightMapColor;  // 已禁用
    
    fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
}